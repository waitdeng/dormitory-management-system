import { test } from '@playwright/test'

test('debug allocation tree', async ({ page }) => {
  page.on('pageerror', (e) => console.log('PAGEERROR', e.message))
  page.on('console', (m) => {
    if (m.type() === 'error') console.log('CONSOLE', m.text().slice(0, 300))
  })
  await page.goto('/login')
  await page.getByPlaceholder('请输入用户名').fill(process.env.DMS_ADMIN_USERNAME || 'admin')
  await page.getByPlaceholder('请输入密码').fill(process.env.DMS_ADMIN_PASSWORD || 'admin12345')
  await page.getByRole('button', { name: /登\s*录/ }).click()
  await page.waitForURL(/dashboard/)
  await page.goto('/bed-allocation')
  await page.waitForTimeout(4000)
  const nodes = await page.locator('.el-tree-node__content').count()
  console.log('NODE_COUNT', nodes)
  for (let i = 0; i < Math.min(nodes, 5); i++) {
    console.log('NODE', i, await page.locator('.el-tree-node__content').nth(i).innerText())
  }
  const body = await page.locator('body').innerText()
  console.log('BODY_HEAD', body.slice(0, 800))
})
