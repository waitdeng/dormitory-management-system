# 项目上下文（PROJECT_CONTEXT）

> 本文件说明项目的业务背景、技术边界与当前状态，供 AI 代理建立统一上下文。
> 路径均相对于项目根目录。

## 1. 项目概述

- **项目名称**：公司宿舍入住管理系统（DMS，Dormitory Management System）
- **版本**：V1.0
- **业务目标**：为企业内部行政、人事提供可私有化部署的宿舍管理 Web 平台，覆盖员工 → 宿舍资源 → 预留/入住 → 调宿 → 退宿 → 离职联动 → 台账/报表全链路。
- **使用对象**：行政、人事等内部管理人员；非员工自助产品。

## 2. 业务边界（V1.0）

**必做范围**见 `DMS_V1.0_MiMo_Development_Spec.md` 第 1 节，概括为：

- 部门与员工档案（含 Excel 导入校验/预览/提交/错误报告、导出）
- 宿舍资源层级：区域 → 楼栋 → 楼层 → 房间 → 床位
- 入住申请、批准、预留、确认、取消与历史
- 调宿（目标预留、原位释放、历史关联）
- 退宿申请、检查、确认、释放床位与历史
- 离职联动（生成退宿待办，**不自动释放床位**）
- 住宿台账、空床/入住率/部门/入退宿/异常统计与导出
- 可视化床位分配
- 登录、RBAC、数据范围、审计、Docker Compose 部署与测试

**明确不做（V1.0）**：住宿费、水电费、押金、薪资代扣、宿舍资产、维修工单、巡检、员工自助小程序、企业微信推送、外部 HR/ERP 集成。

## 3. 技术栈

| 层 | 选型 |
|---|---|
| 前端 | Vue 3 + TypeScript + Vite + Element Plus + Pinia + Vue Router；图表 ECharts |
| 后端 | Python FastAPI + Pydantic v2 + SQLAlchemy 2.x（异步）+ asyncmy |
| 数据库 | MySQL 8.0（InnoDB、utf8mb4），Alembic 迁移 |
| Excel | openpyxl |
| 部署 | Docker Compose + Nginx；Redis 可选，不得作为唯一业务状态源 |
| 测试 | pytest/httpx；前端 Vitest；并发占床集成测试 |
| 架构 | 模块化单体、前后端分离；API → Service → Repository → Model |

API 前缀：`/api/v1`。

## 4. 当前阶段状态

- 项目已完成 **M1～M6** 开发阶段（以 `docs/M1_ACCEPTANCE_REPORT.md` … `docs/M6_ACCEPTANCE_REPORT.md` 为准）。
- **禁止**将已完成阶段重置为待开发，**禁止**删除已有验收报告。
- 后续开发须遵循 AI-SDLC 工作流（见 `AGENTS.md` 与 `.ai/DEVELOPMENT_RULES.md`）。
- 未读取验收报告前，不得断言某阶段“已测试通过”；区分“文档计划完成”与“代码已实现/已验证”。

## 5. 权威文档入口

| 主题 | 路径 |
|---|---|
| 代理协作总则与优先级 | `AGENTS.md` |
| 业务开发规格（项目专属） | `DMS_V1.0_MiMo_Development_Spec.md` |
| 开发规则 | `.ai/DEVELOPMENT_RULES.md` |
| 里程碑与阶段状态 | `.ai/MILESTONES.md` |
| 设计决策 | `.ai/DECISIONS.md` 与 `docs/DECISIONS.md` |
| 阶段计划 | `docs/IMPLEMENTATION_PLAN.md` |
| 阶段验收 | `docs/M1_ACCEPTANCE_REPORT.md` … `docs/M6_ACCEPTANCE_REPORT.md` |
| 部署/备份/发布 | `docs/DEPLOYMENT.md`、`docs/BACKUP_RESTORE.md`、`docs/RELEASE_CHECKLIST.md` |
| API / 数据库设计 | `docs/API_SPECIFICATION.md`、`docs/DATABASE_DESIGN.md`（以实际存在为准） |

## 6. 不变量摘要

核心业务不变量（详见 `DMS_V1.0_MiMo_Development_Spec.md` 与 `AGENTS.md`）：

1. 同一员工同一时刻最多一条 active 住宿记录。
2. 同一床位同一时刻最多一条 active 住宿记录。
3. 预留与住宿记录不得跨表冲突。
4. 停用/维修/上级不可分配时禁止新增分配。
5. 离职产生退宿待办，不直接移除当前住宿。
6. 调宿/退宿保留历史，不覆写删除。
7. 人数/空床/住宿状态由权威业务记录推导。
8. 并发分配在数据库事务中校验（锁顺序：员工行 → bed_id 升序床位行 → 住宿/预留/业务单据）。
9. 重复提交/完成/离职事件须幂等或防重。
10. 关键操作写审计日志。
