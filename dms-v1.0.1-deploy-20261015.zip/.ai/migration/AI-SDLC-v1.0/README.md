# AI-SDLC v1.0

统一 AI 辅助软件开发生命周期（AI-SDLC）规范包。

## 目录结构

```
AGENTS.md                 # 代理入口样例
README.md                 # 本说明
.ai/
  PROJECT_CONTEXT.md      # 项目上下文模板
  DEVELOPMENT_RULES.md    # 开发规则（跨项目通用）
  MILESTONES.md           # 里程碑约定
  DECISIONS.md            # 决策记录约定
  prompts/                # 阶段指令模板
  templates/              # 验收/缺陷模板
  audit/                  # 最终验收模板
```

## 接入方式

1. 将本规范包与项目已有文档合并（保留项目专属规则）。
2. 在项目根维护 `AGENTS.md` 作为优先级与入口。
3. 在 `.ai/` 下维护通用规范；`docs/` 保留项目阶段文档。
4. 冲突写入决策记录，不得静默覆盖。

## 开发流程

GPT Web 编写阶段指令 → MiMo 开发 → MiMo 自动化自检 → GPT Web 复核 → GitHub 提交阶段版本。

涉及 Web 页面/交互修改时，使用 MiMo 自带 Playwright 做真实浏览器测试并留存截图与结果。
全部阶段结束后，由 ChatGPT Mac Work 在隔离测试环境进行最终 UI/UX 与端到端验收。
测试未实际执行必须标记为未测试。
