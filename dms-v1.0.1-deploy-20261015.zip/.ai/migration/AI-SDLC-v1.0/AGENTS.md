# AI-SDLC v1.0 模板：AGENTS.md

> 本文件是 AI-SDLC v1.0 规范包中的 AGENTS.md 样例，迁移时应与项目实际 AGENTS.md 合并，而非直接覆盖项目文件。

## 角色

AGENTS.md 是 AI 编程代理进入仓库后的**第一入口**，职责：

1. 声明规则优先级与冲突处理。
2. 提供各规范文档的导航入口。
3. 约束代理行为（禁止覆盖用户成果、禁止虚构测试结果等）。

## 规则优先级

1. 用户当次明确指令
2. 项目专属规格与 `AGENTS.md`（业务约束）
3. `.ai/DEVELOPMENT_RULES.md`（跨项目通用规则）
4. 各阶段计划与验收文档

## 必读文档

- `.ai/PROJECT_CONTEXT.md`
- `.ai/DEVELOPMENT_RULES.md`
- `.ai/MILESTONES.md`
- `.ai/DECISIONS.md`

## 开发工作流（AI-SDLC）

```
GPT Web 编写阶段指令 → MiMo 开发 → MiMo 自动化自检 → GPT Web 复核 → GitHub 提交阶段版本
```

- Web 前端涉及页面或交互修改时，必须使用 Playwright 执行真实浏览器测试，并保存截图、测试命令和结果。
- 全部阶段结束后，由 ChatGPT Mac Work 在隔离测试环境进行最终 UI/UX 和端到端验收。
- 任何测试未实际执行时，必须明确标记为未测试。
